*PADS-LIBRARY-PART-TYPES-V9*

M20-7820646 HDRV6W70P0X254_1X6_1564X250X850P I CON 7 1 0 0 0
TIMESTAMP 2026.09.17.18.49.35
"Mouser Part Number" 855-M20-7820646
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Harwin/M20-7820646?qs=WS5Jv%252B%252Bx1qWZs4rbTjPGWw%3D%3D
"Manufacturer_Name" Harwin
"Manufacturer_Part_Number" M20-7820646
"Description" M20: 6 Pos Receptacle SIL Straight 3mm THT Connector 8.5mm high Tin
"Datasheet Link" https://content.harwin.com/m/c2ac50ebb1c800d5/original/DRG-00385-Technical-Drawing-Datasheet-M20-782-pdf.pdf
"Geometry.Height" 8.5mm
GATE 1 6 0
M20-7820646
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6

*END*
*REMARK* SamacSys ECAD Model
553575/2023563/2.50/6/2/Connector
